#ifndef TRANSFORM_H_
#define TRANSFORM_H_

#include "../ecs/Component.h"
#include "../game/ecs_def.h"
#include "../utils/Vector2D.h"

using namespace ecs;

struct Transform : public Component 
{
public:
	constexpr static cmpId_type id = TRANSFORM;
	Transform(Vector2D p, Vector2D d, float w, float h, float r) : 
		pos(p), dir(d), width(w), height(h), rotation(r) {}
	virtual ~Transform() {}
	inline Vector2D& getPos() { return pos; }
	inline void setPos(const Vector2D& p) { pos = p; }
	inline Vector2D& getDir() { return dir; }
	inline void setDir(const Vector2D& d) { dir = d; }
	inline void resetDir() { dir = Vector2D(0, 0); }
	inline Vector2D& getCenter() { return center; }
	inline float& getRot() { return rotation; }
	inline void setRot(float rot) { rotation = rot; }
	inline float& getW() { return width; }
	inline float& getH() { return height; }

	void initComponent() override;
private:
	Vector2D pos;
	Vector2D dir;
	Vector2D center;
	float width;
	float height;
	float rotation;
};

#endif /*TRANSFORM_H_*/